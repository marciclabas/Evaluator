var hierarchy =
[
    [ "ICanSolveProblems", "classICanSolveProblems.html", [
      [ "User", "classUser.html", null ]
    ] ],
    [ "IPrintable", "classIPrintable.html", [
      [ "Course", "classCourse.html", null ],
      [ "CourseSet", "classCourseSet.html", null ],
      [ "Problem", "classProblem.html", null ],
      [ "ProblemCollection", "classProblemCollection.html", null ],
      [ "Session", "classSession.html", null ],
      [ "SessionRepository", "classSessionRepository.html", null ],
      [ "User", "classUser.html", null ],
      [ "User::ProblemStats", "structUser_1_1ProblemStats.html", null ],
      [ "UserSet", "classUserSet.html", null ]
    ] ],
    [ "IReadable", "classIReadable.html", [
      [ "Course", "classCourse.html", null ],
      [ "CourseSet", "classCourseSet.html", null ],
      [ "ProblemCollection", "classProblemCollection.html", null ],
      [ "Session", "classSession.html", null ],
      [ "SessionRepository", "classSessionRepository.html", null ],
      [ "UserSet", "classUserSet.html", null ]
    ] ],
    [ "User::UserStats", "structUser_1_1UserStats.html", null ]
];