var classReadable =
[
    [ "Readable", "classReadable.html#a621b5cc627614de05519367da8e69974", null ],
    [ "operator>>", "classReadable.html#af3a96f748864c6204a1cef210b47f010", null ]
];