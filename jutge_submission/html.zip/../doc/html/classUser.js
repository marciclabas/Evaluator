var classUser =
[
    [ "ProblemStats", "structUser_1_1ProblemStats.html", "structUser_1_1ProblemStats" ],
    [ "UserStats", "structUser_1_1UserStats.html", "structUser_1_1UserStats" ],
    [ "User", "classUser_a4a0137053e591fbb79d9057dd7d2283d.html#a4a0137053e591fbb79d9057dd7d2283d", null ],
    [ "~User", "classUser_ac00b72ad64eb4149f7b21b9f5468c2b2.html#ac00b72ad64eb4149f7b21b9f5468c2b2", null ],
    [ "updateSolvableProblems", "classUser_a9502bc778ae19e195fa1e2a27f8d8ef4.html#a9502bc778ae19e195fa1e2a27f8d8ef4", null ],
    [ "getEnrolledCourseID", "classUser_a58f94778be2ff3c33932def944ff3743.html#a58f94778be2ff3c33932def944ff3743", null ],
    [ "getSolvedStats", "classUser_a2b61b100681ea333f19f7b3c9e836875.html#a2b61b100681ea333f19f7b3c9e836875", null ],
    [ "getSolvableStats", "classUser_abceaa2bc54ee3bdc945a1edab880f37d.html#abceaa2bc54ee3bdc945a1edab880f37d", null ],
    [ "isEnrolledInCourse", "classUser_afab0e9d7bbd0acc257f4b747c404e231.html#afab0e9d7bbd0acc257f4b747c404e231", null ],
    [ "completedEnrolledCourse", "classUser_a940f6469c98ecf341634ac2a55b78eac.html#a940f6469c98ecf341634ac2a55b78eac", null ],
    [ "hasSolvedProblem", "classUser_a8b48f850b7a1457454233a250e87929d.html#a8b48f850b7a1457454233a250e87929d", null ],
    [ "addSolvableProblem", "classUser_a678396f4a28b3cc6d106c04732893468.html#a678396f4a28b3cc6d106c04732893468", null ],
    [ "print", "classUser_a7e3a3b397add1d7969213ee07afa6e30.html#a7e3a3b397add1d7969213ee07afa6e30", null ],
    [ "enrollCourse", "classUser_ae0d7460cd0a7ff8c069b07f573f3a46f.html#ae0d7460cd0a7ff8c069b07f573f3a46f", null ],
    [ "unenrollCourse", "classUser_a37756db9d861c3b26d3060f18ea449ee.html#a37756db9d861c3b26d3060f18ea449ee", null ],
    [ "parseSubmission", "classUser_ad7d1e5f0aa6e6a489b2379511082350f.html#ad7d1e5f0aa6e6a489b2379511082350f", null ],
    [ "isEnrolled", "classUser_a7288f5b1f99dd7ebd5993900fad6ee8f.html#a7288f5b1f99dd7ebd5993900fad6ee8f", null ],
    [ "enrolledCourse", "classUser_aa9aa2d00f1a525a6881ba6cd71b5bd0f.html#aa9aa2d00f1a525a6881ba6cd71b5bd0f", null ],
    [ "stats", "classUser_acbf4c0f02f060c6af9a81b6a215f3538.html#acbf4c0f02f060c6af9a81b6a215f3538", null ],
    [ "solvedProblems", "classUser_a412a235e0f6ed2b43af93ff8e6f23d7c.html#a412a235e0f6ed2b43af93ff8e6f23d7c", null ],
    [ "solvableProblems", "classUser_aa61fdf265b91c1a0c11b12fda46239a1.html#aa61fdf265b91c1a0c11b12fda46239a1", null ]
];