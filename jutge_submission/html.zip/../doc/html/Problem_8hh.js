var Problem_8hh =
[
    [ "Problem", "classProblem.html", "classProblem" ],
    [ "ID", "Problem_8hh.html#ac73f5af4cf1ee8080561c3daea7a437f", null ],
    [ "result", "Problem_8hh.html#a72e825355fbd24713dfb8ef9875aa775", null ]
];