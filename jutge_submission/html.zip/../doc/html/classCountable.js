var classCountable =
[
    [ "Countable", "classCountable.html#a9ca67a93e0464c6233db83a177f39c93", null ],
    [ "count", "classCountable.html#a8fa18450a6ca9647fa1ed9d908e75ab4", null ]
];