var classProblemCollection =
[
    [ "ProblemCollection", "classProblemCollection_a9c64db5612113ea8c9cf2f4756fc1abf.html#a9c64db5612113ea8c9cf2f4756fc1abf", null ],
    [ "~ProblemCollection", "classProblemCollection_a315db5b8fb5f98166e1b62e7d5e6517d.html#a315db5b8fb5f98166e1b62e7d5e6517d", null ],
    [ "ProblemCollection", "classProblemCollection_a7bbc4a1a9504512671c1c1369fbf4239.html#a7bbc4a1a9504512671c1c1369fbf4239", null ],
    [ "operator=", "classProblemCollection_a47b4c57020982feafa72ed61816e96f0.html#a47b4c57020982feafa72ed61816e96f0", null ],
    [ "print", "classProblemCollection_ad49395eb1c71357fdc6130058b39d414.html#ad49395eb1c71357fdc6130058b39d414", null ],
    [ "read", "classProblemCollection_a98230806a6e42b5875c102f7de345238.html#a98230806a6e42b5875c102f7de345238", null ],
    [ "contains", "classProblemCollection_aadc7afc414c274888e3deb3c126c5416.html#aadc7afc414c274888e3deb3c126c5416", null ],
    [ "operator[]", "classProblemCollection_a1c3c9eb212c1854ea16cb034c8a1bbdd.html#a1c3c9eb212c1854ea16cb034c8a1bbdd", null ],
    [ "count", "classProblemCollection_a980471ab3b69e04ce772108dbd629194.html#a980471ab3b69e04ce772108dbd629194", null ],
    [ "add", "classProblemCollection_a6bed10344c048d05d710c729d3729301.html#a6bed10344c048d05d710c729d3729301", null ],
    [ "problems", "classProblemCollection_a2294b1ea5899056d21064469ea1af1f1.html#a2294b1ea5899056d21064469ea1af1f1", null ]
];