var ProblemCol_8hh =
[
    [ "ProblemCollection", "classProblemCollection.html", "classProblemCollection" ],
    [ "position", "ProblemCol_8hh.html#a71cbecad48ae1ce5262be6d62ddc5380", null ]
];