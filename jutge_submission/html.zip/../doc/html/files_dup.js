var files_dup =
[
    [ "BinTree.hh", "BinTree_8hh.html", null ],
    [ "Course.hh", "Course_8hh.html", [
      [ "Course", "classCourse.html", "classCourse" ]
    ] ],
    [ "CourseSet.hh", "CourseSet_8hh.html", [
      [ "CourseSet", "classCourseSet.html", "classCourseSet" ]
    ] ],
    [ "ICanSolveProblems.hh", "ICanSolveProblems_8hh.html", [
      [ "ICanSolveProblems", "classICanSolveProblems.html", "classICanSolveProblems" ]
    ] ],
    [ "IO.hh", "IO_8hh.html", "IO_8hh" ],
    [ "IPrintable.hh", "IPrintable_8hh.html", [
      [ "IPrintable", "classIPrintable.html", "classIPrintable" ]
    ] ],
    [ "IReadable.hh", "IReadable_8hh.html", [
      [ "IReadable", "classIReadable.html", "classIReadable" ]
    ] ],
    [ "Namespaces.hh", "Namespaces_8hh.html", "Namespaces_8hh" ],
    [ "Problem.hh", "Problem_8hh.html", [
      [ "Problem", "classProblem.html", "classProblem" ]
    ] ],
    [ "ProblemCol.hh", "ProblemCol_8hh.html", [
      [ "ProblemCollection", "classProblemCollection.html", "classProblemCollection" ]
    ] ],
    [ "program.cc", "program_8cc.html", "program_8cc" ],
    [ "Session.hh", "Session_8hh.html", [
      [ "Session", "classSession.html", "classSession" ]
    ] ],
    [ "SessionRep.hh", "SessionRep_8hh.html", [
      [ "SessionRepository", "classSessionRepository.html", "classSessionRepository" ]
    ] ],
    [ "User.hh", "User_8hh.html", [
      [ "User", "classUser.html", "classUser" ],
      [ "UserStats", "structUser_1_1UserStats.html", "structUser_1_1UserStats" ],
      [ "ProblemStats", "structUser_1_1ProblemStats.html", "structUser_1_1ProblemStats" ]
    ] ],
    [ "UserSet.hh", "UserSet_8hh.html", [
      [ "UserSet", "classUserSet.html", "classUserSet" ]
    ] ]
];