var classReducible =
[
    [ "Reducible", "classReducible.html#aab923b7f47d93fabe6b691c1a6673ab0", null ],
    [ "remove", "classReducible.html#a3972f97ae254e52ca89bee2a71460090", null ]
];