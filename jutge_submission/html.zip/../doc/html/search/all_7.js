var searchData=
[
  ['hassolvedproblem_53',['hasSolvedProblem',['../classICanSolveProblems.html#a3c66ab6e449a42b0ae996a6b8993eb07',1,'ICanSolveProblems::hasSolvedProblem()'],['../classUser.html#a8b48f850b7a1457454233a250e87929d',1,'User::hasSolvedProblem()']]]
];
