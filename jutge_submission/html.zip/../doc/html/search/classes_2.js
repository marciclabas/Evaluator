var searchData=
[
  ['problem_174',['Problem',['../classProblem.html',1,'']]],
  ['problemcollection_175',['ProblemCollection',['../classProblemCollection.html',1,'']]],
  ['problemstats_176',['ProblemStats',['../structUser_1_1ProblemStats.html',1,'User']]]
];
