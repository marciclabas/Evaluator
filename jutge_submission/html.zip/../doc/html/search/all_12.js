var searchData=
[
  ['valid_156',['valid',['../classCourse.html#a966fe9048c51f4c5114923260c4b331b',1,'Course']]]
];
