var classProblem =
[
    [ "Problem", "classProblem_ad9d44f0ef936fb62f0ce41dd200494ac.html#ad9d44f0ef936fb62f0ce41dd200494ac", null ],
    [ "~Problem", "classProblem_a839a525ed01c34d57fff42583003d3e7.html#a839a525ed01c34d57fff42583003d3e7", null ],
    [ "getRatio", "classProblem_a9b103faccfd87982f941c468802b4a22.html#a9b103faccfd87982f941c468802b4a22", null ],
    [ "parseSubmission", "classProblem_ab5522d13d71c4bdf1ea4f8a4cd891f9c.html#ab5522d13d71c4bdf1ea4f8a4cd891f9c", null ],
    [ "print", "classProblem_a743af7c886c13ce185a988b2d3e7d789.html#a743af7c886c13ce185a988b2d3e7d789", null ],
    [ "t", "classProblem_adb5240ca06e0a6e5ebb13c69d8315cf3.html#adb5240ca06e0a6e5ebb13c69d8315cf3", null ],
    [ "e", "classProblem_aca6215a0cd094ce01582821234ee81bc.html#aca6215a0cd094ce01582821234ee81bc", null ],
    [ "r", "classProblem_a34720261fb68d7602632f0cf07da0698.html#a34720261fb68d7602632f0cf07da0698", null ]
];