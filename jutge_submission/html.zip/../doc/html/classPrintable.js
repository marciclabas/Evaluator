var classPrintable =
[
    [ "Printable", "classPrintable.html#a9393b7235b98efcaef86cd120287ef42", null ],
    [ "operator<<", "classPrintable.html#acf1004cfa2b6b5884a75a9e3bed03a62", null ]
];