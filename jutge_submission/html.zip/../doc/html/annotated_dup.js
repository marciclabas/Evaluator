var annotated_dup =
[
    [ "Course", "classCourse.html", "classCourse" ],
    [ "CourseSet", "classCourseSet.html", "classCourseSet" ],
    [ "ICanSolveProblems", "classICanSolveProblems.html", "classICanSolveProblems" ],
    [ "IPrintable", "classIPrintable.html", "classIPrintable" ],
    [ "IReadable", "classIReadable.html", "classIReadable" ],
    [ "Problem", "classProblem.html", "classProblem" ],
    [ "ProblemCollection", "classProblemCollection.html", "classProblemCollection" ],
    [ "Session", "classSession.html", "classSession" ],
    [ "SessionRepository", "classSessionRepository.html", "classSessionRepository" ],
    [ "User", "classUser.html", "classUser" ],
    [ "UserSet", "classUserSet.html", "classUserSet" ]
];