var classSessionRepository =
[
    [ "SessionRepository", "classSessionRepository_a8d8416dc1fe09f2de09b7904db426637.html#a8d8416dc1fe09f2de09b7904db426637", null ],
    [ "~SessionRepository", "classSessionRepository_adbef927f8d88802b2dabad68929409a6.html#adbef927f8d88802b2dabad68929409a6", null ],
    [ "SessionRepository", "classSessionRepository_ae4aec97d83299867b739dae791a8ca1c.html#ae4aec97d83299867b739dae791a8ca1c", null ],
    [ "operator=", "classSessionRepository_acef0bd026fd3aee99e1306c5ca8bd6b2.html#acef0bd026fd3aee99e1306c5ca8bd6b2", null ],
    [ "print", "classSessionRepository_afa26909ce41c3a4b17a49eb0e56dd4f6.html#afa26909ce41c3a4b17a49eb0e56dd4f6", null ],
    [ "read", "classSessionRepository_a65ec9cf8253a692bb4016fb3784b7bf8.html#a65ec9cf8253a692bb4016fb3784b7bf8", null ],
    [ "contains", "classSessionRepository_a324f09ca93e28d071329e49794e742dd.html#a324f09ca93e28d071329e49794e742dd", null ],
    [ "contains", "classSessionRepository_a547e0417386f9ac1972b5f2f1518b871.html#a547e0417386f9ac1972b5f2f1518b871", null ],
    [ "operator[]", "classSessionRepository_a789aab908664b816733f94a53ae970df.html#a789aab908664b816733f94a53ae970df", null ],
    [ "count", "classSessionRepository_ac157d3e9e342a7b78c487250001f661d.html#ac157d3e9e342a7b78c487250001f661d", null ],
    [ "add", "classSessionRepository_aeb44714b8721f5fa62da6944b1fab46f.html#aeb44714b8721f5fa62da6944b1fab46f", null ],
    [ "sessions", "classSessionRepository_ad7d69af4d4b4f067b2f7dadeb502a4d1.html#ad7d69af4d4b4f067b2f7dadeb502a4d1", null ]
];