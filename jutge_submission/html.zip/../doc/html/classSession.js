var classSession =
[
    [ "const_iterator", "classSession_ae6a2d3f11b14ca0e7f68d66d846b5855.html#ae6a2d3f11b14ca0e7f68d66d846b5855", null ],
    [ "Session", "classSession_ad92ef09b872c9227e38a6efdd4d8a837.html#ad92ef09b872c9227e38a6efdd4d8a837", null ],
    [ "~Session", "classSession_a8753bb9dee966b7d39abc9b7237cd665.html#a8753bb9dee966b7d39abc9b7237cd665", null ],
    [ "addProblemToSet", "classSession_a25ac4518727f816e5c4815e38014b271.html#a25ac4518727f816e5c4815e38014b271", null ],
    [ "readImmersion", "classSession_a2f768ef5d1466e889c1cfc04e1da802d.html#a2f768ef5d1466e889c1cfc04e1da802d", null ],
    [ "print", "classSession_aa378fcde1f8e4572b9599c975dc8d354.html#aa378fcde1f8e4572b9599c975dc8d354", null ],
    [ "read", "classSession_a8af7ea5fb236ceb581e39d215b4c0811.html#a8af7ea5fb236ceb581e39d215b4c0811", null ],
    [ "containsProblem", "classSession_a6032e66d3bef1b33d5b01762bd4bca4d.html#a6032e66d3bef1b33d5b01762bd4bca4d", null ],
    [ "updateSolvableProblems", "classSession_a77f3a81755f2ef5febfaec93ef587911.html#a77f3a81755f2ef5febfaec93ef587911", null ],
    [ "getCount", "classSession_a9e1c974241d60d762ef3dc3dc1a8ba97.html#a9e1c974241d60d762ef3dc3dc1a8ba97", null ],
    [ "begin", "classSession_a0735755f0145dbd9d8d3a37dd6ea617d.html#a0735755f0145dbd9d8d3a37dd6ea617d", null ],
    [ "end", "classSession_a2c6a3101c2fe847962b1348780918085.html#a2c6a3101c2fe847962b1348780918085", null ],
    [ "operator==", "classSession_a8baa3a14784e12bdfb1f668f4e3fd6e2.html#a8baa3a14784e12bdfb1f668f4e3fd6e2", null ],
    [ "problems", "classSession_afaa854c8a4f5c6196f01a8c8953b1ee0.html#afaa854c8a4f5c6196f01a8c8953b1ee0", null ],
    [ "problemsSet", "classSession_a1d7fdb77a86c4fd4b49367c4e6d4149e.html#a1d7fdb77a86c4fd4b49367c4e6d4149e", null ],
    [ "count", "classSession_a3abd4677f90bf25dde94a9d8f575cd4e.html#a3abd4677f90bf25dde94a9d8f575cd4e", null ]
];