var classExpandable =
[
    [ "Expandable", "classExpandable.html#a3ba60642fbc76dac58967dcc98570713", null ],
    [ "add", "classExpandable.html#a8c9225baf01ca9bae1a95ccd42e666d9", null ]
];