var namespaceusr =
[
    [ "ProblemStats", "classusr_1_1ProblemStats.html", null ],
    [ "ID", "namespaceusr.html#afed849d06665ce63a85325c909efe771", null ],
    [ "completedCourse", "namespaceusr.html#aebc510b63859f70383fc6edba6c5d0cf", null ],
    [ "position", "namespaceusr.html#a08e507b43800b81534061357ec81cddd", null ]
];