var Course_8hh =
[
    [ "Course", "classCourse.html", "classCourse" ],
    [ "ID", "Course_8hh.html#ad6124b1a4ba860befee7a8499688e758", null ]
];